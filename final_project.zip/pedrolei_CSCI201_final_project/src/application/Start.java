package application;

import javafx.application.Application;

public class Start
{

	public static void main(String[] args)
	{
		//Main mainMenu = new Main();
		Application.launch(MainMenu.class, args);

	}

}
